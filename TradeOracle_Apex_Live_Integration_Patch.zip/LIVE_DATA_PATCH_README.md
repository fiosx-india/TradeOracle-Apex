# TradeOracle Apex — Coordinated Live-Data Patch

## Files included

- `config.py`
- `data/market_data.py`
- `core/market_context.py`
- `core/master_brain.py`
- `core/orchestrator.py`
- `main.py`

These files are designed as one coordinated set.

## Important

This patch does **not** invent a provider or pretend that a public stream is
already connected. The repository's MarketData architecture is provider-
agnostic: a real provider object must be injected.

The resulting flow is:

REAL PROVIDER
→ MarketData normalization/quality
→ MarketContext
→ Research
→ Base Prediction
→ Meta/Derived
→ Evidence Fusion
→ Final Decision

## Existing 21-engine architecture

The registry/discovery/validation/benchmark/registration pipeline is preserved.
Meta engines remain derived outputs and are not independent final votes.

## After upload

Run the existing registration test first:

python -c "from core.orchestrator import ApexOrchestrator; o=ApexOrchestrator(); o.discover_validate_benchmark_register(); print('COUNT=', len(o.registry.all()))"

Expected:
COUNT= 21

Then a real provider must be injected into `MarketData` before calling
`evaluate_live(...)`.

Do not switch `APEX_DATA_MODE=live` until the provider is actually attached.

## Why this is not a fake 'READY'

The old readiness diagnostic used `MarketData(provider=None)`. That correctly
reported that no provider was connected. This patch keeps that honesty:
missing/stale/invalid provider data blocks prediction instead of producing a
synthetic price or prediction.
