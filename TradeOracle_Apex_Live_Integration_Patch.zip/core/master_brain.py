"""Apex Master Brain.

Pipeline:
RESEARCH
    ↓
PREDICTION
    ↓
DERIVED / META ANALYSIS
    ↓
EVIDENCE FUSION
    ↓
FINAL DECISION

Derived/meta engines are not counted as independent votes.
"""

from __future__ import annotations

from .decision_engine import DecisionEngine
from .evidence_fusion import EvidenceFusion


class ApexMasterBrain:
    name = "ApexMasterBrain"
    capabilities = ["MASTER_DECISION"]

    META_CAPABILITIES = {
        "ENSEMBLE",
        "PROBABILITY",
        "RANKING",
        "MOVEMENT_PATH",
    }

    def __init__(self, registry=None, router=None):
        self.registry = registry
        self.router = router
        self.fusion = EvidenceFusion()
        self.decision = DecisionEngine()

    def attach_registry(self, registry, router=None):
        self.registry = registry
        self.router = router

    @staticmethod
    def _capabilities(engine):
        value = getattr(engine, "capabilities", [])
        if isinstance(value, (list, tuple, set)):
            return {
                str(item).upper()
                for item in value
            }
        return set()

    @staticmethod
    def _set_context_value(context, key, value):
        if isinstance(context, dict):
            context[key] = value
            return

        try:
            setattr(context, key, value)
        except Exception:
            pass

    @staticmethod
    def _get_context_value(context, key, default=None):
        if isinstance(context, dict):
            return context.get(key, default)
        return getattr(context, key, default)

    def _run_engine(self, engine, context):
        try:
            analyze = getattr(engine, "analyze", None)
            predict = getattr(engine, "predict", None)

            if callable(analyze):
                result = analyze(context)
            elif callable(predict):
                result = predict(context)
            else:
                return None

            if not isinstance(result, dict):
                return None

            item = dict(result)
            item.setdefault(
                "engine",
                getattr(
                    engine,
                    "name",
                    engine.__class__.__name__,
                ),
            )
            item.setdefault("weight", 1.0)
            item.setdefault("confidence", 1.0)

            return item

        except Exception as exc:
            return {
                "engine": getattr(
                    engine,
                    "name",
                    engine.__class__.__name__,
                ),
                "score": 0.0,
                "weight": 0.0,
                "confidence": 0.0,
                "reason": f"engine_error:{type(exc).__name__}",
            }

    def _collect_stage(self, context, required_capability):
        if self.registry is None:
            return []

        evidence = []

        for engine in self.registry.all().values():
            capabilities = self._capabilities(engine)

            if required_capability not in capabilities:
                continue

            item = self._run_engine(engine, context)

            if item is not None:
                evidence.append(item)

        return evidence

    def _collect_research(self, context):
        research = self._collect_stage(context, "RESEARCH")
        self._set_context_value(
            context,
            "research_evidence",
            research,
        )
        return research

    def _collect_prediction(self, context):
        prediction = []

        if self.registry is None:
            return prediction

        for engine in self.registry.all().values():
            capabilities = self._capabilities(engine)

            if "PREDICTION" not in capabilities:
                continue

            if capabilities.intersection(self.META_CAPABILITIES):
                continue

            item = self._run_engine(engine, context)

            if item is not None:
                prediction.append(item)

        self._set_context_value(
            context,
            "prediction_evidence",
            prediction,
        )

        return prediction

    def _collect_meta(self, context):
        meta = []

        if self.registry is None:
            return meta

        for engine in self.registry.all().values():
            capabilities = self._capabilities(engine)

            if not capabilities.intersection(self.META_CAPABILITIES):
                continue

            item = self._run_engine(engine, context)

            if item is not None:
                meta.append(item)

        self._set_context_value(
            context,
            "meta_evidence",
            meta,
        )

        return meta

    @staticmethod
    def _select_final_evidence(
        research_evidence,
        prediction_evidence,
    ):
        usable_prediction = [
            item
            for item in prediction_evidence
            if isinstance(item, dict)
            and float(item.get("weight", 0.0)) > 0
        ]

        if usable_prediction:
            return usable_prediction

        return research_evidence

    def collect_evidence(self, context):
        if self.registry is None:
            return []

        research_evidence = self._collect_research(context)
        prediction_evidence = self._collect_prediction(context)
        meta_evidence = self._collect_meta(context)

        self._set_context_value(
            context,
            "research_evidence",
            research_evidence,
        )
        self._set_context_value(
            context,
            "prediction_evidence",
            prediction_evidence,
        )
        self._set_context_value(
            context,
            "meta_evidence",
            meta_evidence,
        )

        return self._select_final_evidence(
            research_evidence,
            prediction_evidence,
        )

    @staticmethod
    def _find_meta(meta_evidence, engine_name):
        for item in meta_evidence:
            if str(item.get("engine", "")) == engine_name:
                return item
        return None

    def evaluate(self, context):
        evidence = self.collect_evidence(context)

        fused = self.fusion.combine(evidence)
        decision = self.decision.decide(fused)

        research_evidence = self._get_context_value(
            context, "research_evidence", []
        )
        prediction_evidence = self._get_context_value(
            context, "prediction_evidence", []
        )
        meta_evidence = self._get_context_value(
            context, "meta_evidence", []
        )

        horizon_minutes = self._get_context_value(
            context, "horizon_minutes", 60
        )

        return {
            "horizon_minutes": horizon_minutes,
            "decision": decision,
            "research_evidence": research_evidence,
            "prediction_evidence": prediction_evidence,
            "meta_evidence": meta_evidence,
            "derived": {
                "probability": self._find_meta(
                    meta_evidence, "ProbabilityEngine"
                ),
                "ensemble": self._find_meta(
                    meta_evidence, "EnsembleEngine"
                ),
                "ranking": self._find_meta(
                    meta_evidence, "RankingEngine"
                ),
                "movement_path": self._find_meta(
                    meta_evidence, "MovementPathEngine"
                ),
            },
        }
