"""Full Apex lifecycle with optional live market-data context.

Discover -> Validate -> Benchmark -> Register -> Master Brain.

The orchestrator does not invent market data. A real MarketData provider
must be injected by the caller/application layer.
"""

from __future__ import annotations

from typing import Any, Optional

from .capability_router import CapabilityRouter
from .market_context import MarketContext
from .master_brain import ApexMasterBrain
from .system_registry import SystemRegistry

from plugins.plugin_benchmark import PluginBenchmark
from plugins.plugin_loader import PluginLoader
from plugins.plugin_validator import PluginValidator

from config import (
    INCOMING_DIR,
    MARKET_DATA_MAX_AGE_SECONDS,
    MIN_MARKET_RECORDS,
    PREDICTION_HORIZON_MINUTES,
)


class ApexOrchestrator:
    def __init__(self, incoming=INCOMING_DIR, market_data=None):
        self.incoming = incoming
        self.market_data = market_data

        self.registry = SystemRegistry()
        self.router = CapabilityRouter(self.registry)
        self.validator = PluginValidator()
        self.benchmark = PluginBenchmark()

        self.brain = ApexMasterBrain(
            registry=self.registry,
            router=self.router,
        )

    def discover_validate_benchmark_register(self):
        report = []
        loader = PluginLoader(self.incoming)

        for item in loader.discover():
            if not item["loaded"]:
                report.append(item)
                continue

            engine = item["engine"]

            validation = self.validator.validate(engine)

            if not validation["valid"]:
                report.append({
                    "stage": "VALIDATION",
                    "status": "REJECTED",
                    "name": getattr(
                        engine,
                        "name",
                        item["file"],
                    ),
                    "file": item["file"],
                    "errors": validation["errors"],
                })
                continue

            benchmark = self.benchmark.benchmark(engine)

            if not benchmark["passed"]:
                report.append({
                    "stage": "BENCHMARK",
                    "status": "REJECTED",
                    "name": engine.name,
                    "file": item["file"],
                    "errors": benchmark["errors"],
                    "benchmark": benchmark,
                })
                continue

            self.registry.register(
                engine,
                benchmark=benchmark,
                source_file=item["file"],
            )

            report.append({
                "stage": "REGISTRATION",
                "status": "ACTIVE",
                "name": engine.name,
                "file": item["file"],
                "benchmark": benchmark,
            })

        self.brain.attach_registry(
            self.registry,
            self.router,
        )

        return report

    def build_market_context(
        self,
        symbol: str,
        *,
        sector: str = "",
        start: Any = None,
        end: Any = None,
        limit: Optional[int] = None,
        **kwargs,
    ) -> MarketContext:
        """Fetch real provider data and convert it to MarketContext.

        No provider/no records/invalid records remain explicit. This method
        never fabricates prices.
        """
        if self.market_data is None:
            raise RuntimeError(
                "No MarketData gateway/provider is attached."
            )

        result = self.market_data.fetch(
            symbol=symbol,
            start=start,
            end=end,
            limit=limit,
            **kwargs,
        )

        quality = result.get("quality", {})

        if quality.get("status") != "OK":
            raise RuntimeError(
                "Market data is not prediction-ready: "
                f"{quality.get('status')}"
            )

        if not quality.get("fresh", False):
            raise RuntimeError(
                "Market data is stale."
            )

        records = result.get("records", [])

        if len(records) < max(1, MIN_MARKET_RECORDS):
            raise RuntimeError(
                "Insufficient recent market records: "
                f"{len(records)} < {MIN_MARKET_RECORDS}"
            )

        return MarketContext.from_records(
            records,
            symbol=symbol,
            sector=sector,
            horizon_minutes=PREDICTION_HORIZON_MINUTES,
            quality=quality,
            source=result.get("source"),
        )

    def evaluate_live(
        self,
        symbol: str,
        *,
        sector: str = "",
        start: Any = None,
        end: Any = None,
        limit: Optional[int] = None,
        **kwargs,
    ) -> dict:
        """Run the complete registered Apex prediction pipeline on live data."""
        context = self.build_market_context(
            symbol=symbol,
            sector=sector,
            start=start,
            end=end,
            limit=limit,
            **kwargs,
        )

        return self.brain.evaluate(context)

    def run(self, context=None):
        report = self.discover_validate_benchmark_register()

        result = {
            "status": "READY",
            "pipeline": [
                "DISCOVER",
                "VALIDATE",
                "BENCHMARK",
                "REGISTER",
                "MASTER_BRAIN",
            ],
            "registered_engines": list(
                self.registry.all()
            ),
            "registry_report": self.registry.report(),
            "report": report,
        }

        if context is not None:
            result["master_brain"] = (
                self.brain.evaluate(context)
            )

        return result
