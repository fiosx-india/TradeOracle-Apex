"""Canonical shared market context for the Apex engine pipeline."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional


@dataclass
class MarketContext:
    """Single normalized context shared by all Apex engines.

    ``data`` contains normalized provider observations and derived series.
    Evidence fields are explicitly part of the contract so research,
    prediction, and meta stages can communicate without hidden attributes.
    """

    timestamp: str
    symbol: str = ""
    sector: str = ""
    horizon_minutes: int = 60
    data: dict[str, Any] = field(default_factory=dict)
    evidence: list[dict[str, Any]] = field(default_factory=list)

    research_evidence: list[dict[str, Any]] = field(default_factory=list)
    prediction_evidence: list[dict[str, Any]] = field(default_factory=list)
    meta_evidence: list[dict[str, Any]] = field(default_factory=list)

    market_quality: dict[str, Any] = field(default_factory=dict)
    source: Optional[str] = None
    live: bool = False

    @classmethod
    def from_records(
        cls,
        records: Iterable[dict[str, Any]],
        *,
        symbol: str = "",
        sector: str = "",
        horizon_minutes: int = 60,
        quality: Optional[dict[str, Any]] = None,
        source: Optional[str] = None,
    ) -> "MarketContext":
        rows = [
            dict(row)
            for row in records
            if isinstance(row, dict)
        ]

        if rows:
            latest = rows[-1]
            timestamp = str(latest.get("timestamp") or "")
            resolved_symbol = (
                str(latest.get("symbol") or symbol)
            )
            live = any(
                bool(row.get("live", False))
                for row in rows
            )
        else:
            timestamp = ""
            resolved_symbol = symbol
            live = False

        data = cls._build_series(rows)

        return cls(
            timestamp=timestamp,
            symbol=resolved_symbol,
            sector=sector,
            horizon_minutes=int(horizon_minutes),
            data=data,
            market_quality=dict(quality or {}),
            source=source,
            live=live,
        )

    @staticmethod
    def _build_series(
        records: list[dict[str, Any]],
    ) -> dict[str, Any]:
        data: dict[str, Any] = {}

        fields = (
            "open",
            "high",
            "low",
            "close",
            "price",
            "volume",
            "change",
            "change_pct",
            "volume_ratio",
            "timestamp",
        )

        for field_name in fields:
            values = [
                row[field_name]
                for row in records
                if field_name in row
                and row[field_name] is not None
            ]

            if values:
                data[field_name] = values

        # Prediction engines already support close/closes and
        # volume/volumes aliases. Preserve those existing contracts.
        if "close" in data:
            data["closes"] = list(data["close"])
            data["price"] = list(data["close"])

        if "volume" in data:
            data["volumes"] = list(data["volume"])
            data["trade_volume"] = list(data["volume"])

        data["records"] = records
        return data

    @property
    def current_price(self) -> Optional[float]:
        for key in ("price", "close"):
            values = self.data.get(key)
            if isinstance(values, (list, tuple)) and values:
                try:
                    return float(values[-1])
                except (TypeError, ValueError):
                    pass
        return None

    @property
    def is_fresh(self) -> bool:
        return bool(self.market_quality.get("fresh", False))

    def set_stage_evidence(
        self,
        *,
        research: Optional[list[dict[str, Any]]] = None,
        prediction: Optional[list[dict[str, Any]]] = None,
        meta: Optional[list[dict[str, Any]]] = None,
    ) -> None:
        if research is not None:
            self.research_evidence = research
        if prediction is not None:
            self.prediction_evidence = prediction
        if meta is not None:
            self.meta_evidence = meta
