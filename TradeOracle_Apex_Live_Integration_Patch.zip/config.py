"""Central, environment-driven Apex configuration."""
import os

APP_NAME = "TradeOracle Apex"
VERSION = "1.2.0"

PREDICTION_HORIZON_MINUTES = int(
    os.getenv("APEX_HORIZON_MINUTES", "60")
)

# demo = diagnostics only; live = real provider is required.
DATA_MODE = os.getenv("APEX_DATA_MODE", "demo").strip().lower()

# Provider name is descriptive/configuration metadata only.
# The actual provider object is injected into MarketData.
DATA_PROVIDER = os.getenv("APEX_DATA_PROVIDER", "").strip()

# Maximum acceptable age of a market observation.
MARKET_DATA_MAX_AGE_SECONDS = int(
    os.getenv("APEX_MARKET_DATA_MAX_AGE_SECONDS", "120")
)

# Require enough recent observations before running prediction.
MIN_MARKET_RECORDS = int(
    os.getenv("APEX_MIN_MARKET_RECORDS", "5")
)

INCOMING_DIR = os.getenv("APEX_INCOMING_DIR", "incoming")

# Direction thresholds are deliberately configurable.
UP_THRESHOLD = float(
    os.getenv("APEX_UP_THRESHOLD", "0.15")
)
DOWN_THRESHOLD = float(
    os.getenv("APEX_DOWN_THRESHOLD", "-0.15")
)

# Never present a model probability as certainty.
MIN_CONFIDENCE_FOR_SIGNAL = float(
    os.getenv("APEX_MIN_CONFIDENCE", "0.60")
)

# Safety switch: prediction is allowed only when the input feed passes
# freshness/quality checks.
REQUIRE_FRESH_MARKET_DATA = (
    os.getenv("APEX_REQUIRE_FRESH_DATA", "true").strip().lower()
    in {"1", "true", "yes", "on"}
)
