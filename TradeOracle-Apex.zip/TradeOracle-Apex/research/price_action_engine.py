"""TradeOracle Apex — price_action_engine.py
Purpose: price action engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class PriceActionEngine:
    name = "PriceActionEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
