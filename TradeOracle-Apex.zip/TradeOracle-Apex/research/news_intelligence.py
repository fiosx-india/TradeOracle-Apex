"""TradeOracle Apex — news_intelligence.py
Purpose: news intelligence layer.
This module is an extension point; connect a validated provider/model here.
"""

class NewsIntelligence:
    name = "NewsIntelligence"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
