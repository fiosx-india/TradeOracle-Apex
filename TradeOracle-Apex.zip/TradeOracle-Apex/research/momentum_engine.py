"""TradeOracle Apex — momentum_engine.py
Purpose: momentum engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class MomentumEngine:
    name = "MomentumEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
