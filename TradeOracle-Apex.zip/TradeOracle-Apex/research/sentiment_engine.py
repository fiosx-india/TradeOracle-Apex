"""TradeOracle Apex — sentiment_engine.py
Purpose: sentiment engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class SentimentEngine:
    name = "SentimentEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
