"""TradeOracle Apex — pattern_engine.py
Purpose: pattern engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class PatternEngine:
    name = "PatternEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
