"""TradeOracle Apex — volume_engine.py
Purpose: volume engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class VolumeEngine:
    name = "VolumeEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
