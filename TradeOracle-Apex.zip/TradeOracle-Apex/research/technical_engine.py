"""TradeOracle Apex — technical_engine.py
Purpose: technical engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class TechnicalEngine:
    name = "TechnicalEngine"
    capabilities = ["RESEARCH"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
