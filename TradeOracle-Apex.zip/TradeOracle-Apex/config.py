import os
APP_NAME='TradeOracle Apex'; VERSION='0.1.0'; PREDICTION_HORIZON_MINUTES=60; TOP_N=10; EARLY_N=5
DATA_MODE=os.getenv('APEX_DATA_MODE','demo')
API_KEYS={'MARKET':os.getenv('MARKET_API_KEY',''),'NEWS':os.getenv('NEWS_API_KEY','')}
