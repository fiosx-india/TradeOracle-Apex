class PluginValidator:
    def validate(self,engine):
        missing=[x for x in ('name','capabilities') if not hasattr(engine,x)]
        return {'valid':not missing,'missing':missing}
