class PluginBenchmark:
    def benchmark(self,engine,samples=None): return {'engine':getattr(engine,'name',type(engine).__name__),'status':'PENDING_DATA'}
