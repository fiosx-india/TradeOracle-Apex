class PluginRegistry:
    def __init__(self): self.items={}
    def add(self,engine): self.items[engine.name]=engine
    def all(self): return dict(self.items)
