"""TradeOracle Apex — commodity_engine.py
Purpose: commodity engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class CommodityEngine:
    name = "CommodityEngine"
    capabilities = ["COMMODITIES"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
