"""TradeOracle Apex — commodity_impact.py
Purpose: commodity impact layer.
This module is an extension point; connect a validated provider/model here.
"""

class CommodityImpact:
    name = "CommodityImpact"
    capabilities = ["COMMODITIES"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
