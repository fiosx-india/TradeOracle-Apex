"""TradeOracle Apex — crude_engine.py
Purpose: crude engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class CrudeEngine:
    name = "CrudeEngine"
    capabilities = ["COMMODITIES"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
