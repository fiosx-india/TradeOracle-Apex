"""TradeOracle Apex — gold_engine.py
Purpose: gold engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class GoldEngine:
    name = "GoldEngine"
    capabilities = ["COMMODITIES"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
