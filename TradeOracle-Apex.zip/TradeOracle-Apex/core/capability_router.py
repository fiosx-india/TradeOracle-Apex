class CapabilityRouter:
    def __init__(self,registry): self.registry=registry
    def route(self,capability): return [e for e in self.registry.all().values() if capability in getattr(e,'capabilities',[])]
