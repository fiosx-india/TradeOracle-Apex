from datetime import datetime,timezone
from .master_brain import ApexMasterBrain
from .system_registry import SystemRegistry
from .capability_router import CapabilityRouter
from plugins.plugin_loader import PluginLoader
class ApexOrchestrator:
    def __init__(self): self.registry=SystemRegistry(); self.router=CapabilityRouter(self.registry); self.brain=ApexMasterBrain()
    def load_plugins(self):
        for name,engine in PluginLoader().discover().items(): self.registry.register(name,engine)
    def run(self):
        self.load_plugins(); return {'app':'TradeOracle Apex','timestamp':datetime.now(timezone.utc).isoformat(),'registered_engines':list(self.registry.all()),'status':'READY'}
