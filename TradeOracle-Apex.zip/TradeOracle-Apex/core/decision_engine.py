class DecisionEngine:
    def decide(self,fused):
        s=fused.get('score',0)
        return {'direction':'UP' if s>.15 else 'DOWN' if s<-.15 else 'SIDEWAYS','confidence':fused.get('confidence',0),'reasons':fused.get('reasons',[])}
