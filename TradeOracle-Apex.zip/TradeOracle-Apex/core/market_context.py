from dataclasses import dataclass, field
from typing import Any, Dict
@dataclass
class MarketContext:
    timestamp:str; symbol:str=''; sector:str=''; horizon_minutes:int=60; data:Dict[str,Any]=field(default_factory=dict); evidence:Dict[str,Any]=field(default_factory=dict)
