class EvidenceFusion:
    def combine(self,evidence):
        vals=[float(x.get('score',0)) for x in evidence if isinstance(x,dict)]
        reasons=[x.get('reason') for x in evidence if isinstance(x,dict) and x.get('reason')]
        score=sum(vals)/len(vals) if vals else 0.0
        return {'score':score,'confidence':min(1.0,abs(score)),'reasons':reasons}
