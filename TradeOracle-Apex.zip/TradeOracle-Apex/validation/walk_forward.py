"""TradeOracle Apex — walk_forward.py
Purpose: walk forward layer.
This module is an extension point; connect a validated provider/model here.
"""

class WalkForward:
    name = "WalkForward"
    capabilities = ["VALIDATION"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
