"""TradeOracle Apex — global_data.py
Purpose: global data layer.
This module is an extension point; connect a validated provider/model here.
"""

class GlobalData:
    name = "GlobalData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
