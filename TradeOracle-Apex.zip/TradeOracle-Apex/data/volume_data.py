"""TradeOracle Apex — volume_data.py
Purpose: volume data layer.
This module is an extension point; connect a validated provider/model here.
"""

class VolumeData:
    name = "VolumeData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
