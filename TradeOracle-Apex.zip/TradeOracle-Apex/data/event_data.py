"""TradeOracle Apex — event_data.py
Purpose: event data layer.
This module is an extension point; connect a validated provider/model here.
"""

class EventData:
    name = "EventData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
