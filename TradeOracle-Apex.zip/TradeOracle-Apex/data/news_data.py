"""TradeOracle Apex — news_data.py
Purpose: news data layer.
This module is an extension point; connect a validated provider/model here.
"""

class NewsData:
    name = "NewsData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
