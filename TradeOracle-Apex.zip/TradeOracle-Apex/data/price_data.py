"""TradeOracle Apex — price_data.py
Purpose: price data layer.
This module is an extension point; connect a validated provider/model here.
"""

class PriceData:
    name = "PriceData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
