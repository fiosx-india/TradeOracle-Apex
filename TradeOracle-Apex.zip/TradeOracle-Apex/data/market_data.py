"""TradeOracle Apex — market_data.py
Purpose: market data layer.
This module is an extension point; connect a validated provider/model here.
"""

class MarketData:
    name = "MarketData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
