"""TradeOracle Apex — macro_data.py
Purpose: macro data layer.
This module is an extension point; connect a validated provider/model here.
"""

class MacroData:
    name = "MacroData"
    capabilities = ["DATA"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
