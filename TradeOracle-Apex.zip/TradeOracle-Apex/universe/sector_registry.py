"""TradeOracle Apex — sector_registry.py
Purpose: sector registry layer.
This module is an extension point; connect a validated provider/model here.
"""

class SectorRegistry:
    name = "SectorRegistry"
    capabilities = ["UNIVERSE"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
