"""TradeOracle Apex — index_engine.py
Purpose: index engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class IndexEngine:
    name = "IndexEngine"
    capabilities = ["UNIVERSE"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
