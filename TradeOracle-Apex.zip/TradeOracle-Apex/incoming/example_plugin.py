class ExamplePlugin:
    name='ExamplePlugin'; capabilities=['RESEARCH']
    def analyze(self,context): return {'score':0.0,'reason':'Demo plugin; replace with a validated engine.'}
PLUGIN_CLASS=ExamplePlugin
