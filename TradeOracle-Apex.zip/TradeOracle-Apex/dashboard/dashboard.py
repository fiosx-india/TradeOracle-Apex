"""TradeOracle Apex — dashboard.py
Purpose: dashboard layer.
This module is an extension point; connect a validated provider/model here.
"""

class Dashboard:
    name = "Dashboard"
    capabilities = ["DASHBOARD"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
