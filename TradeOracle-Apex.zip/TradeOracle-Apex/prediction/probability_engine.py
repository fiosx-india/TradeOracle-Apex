"""TradeOracle Apex — probability_engine.py
Purpose: probability engine layer.
This module is an extension point; connect a validated provider/model here.
"""

class ProbabilityEngine:
    name = "ProbabilityEngine"
    capabilities = ["PREDICTION"]
    def run(self, context=None):
        return {"status": "NOT_CONFIGURED", "engine": self.name}
