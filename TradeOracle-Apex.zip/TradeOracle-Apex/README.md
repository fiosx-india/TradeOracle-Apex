# TradeOracle Apex

Modular market-intelligence foundation for 250-company scanning, NIFTY/SENSEX/BANK NIFTY, commodities, research engines, 60-minute forecasting, early movers/fallers, ranking, validation and drop-in plugins.

## Run
`pip install -r requirements.txt`
`python main.py`

Default mode is `demo`; connect real timestamped market/news providers before live use.

## Drop-in plugins
Put compatible Python plugins into `incoming/`. A plugin exposes `PLUGIN_CLASS`; the loader discovers it without adding imports to core files.

This is an engineering foundation, not a guarantee of trading accuracy. Accuracy must be established with historical and walk-forward validation.
